﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
       

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult showdata()
        {
            return View();
        }

        public IActionResult adddata()
        {
            return View();
        }

        [HttpPost]
        public IActionResult adddata(string Name , string Email , string Password)
        {
            ViewBag.Name = Name;
            ViewBag.Email = Email;
            ViewBag.Password = Password;



            TempData["SuccessMessage"] = "Form has been successfully submitted, " + Name + "!";

            return View("privacy");
        }
    }
}