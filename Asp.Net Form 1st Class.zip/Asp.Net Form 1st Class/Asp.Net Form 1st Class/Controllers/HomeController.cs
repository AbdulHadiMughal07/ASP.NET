﻿using Asp.Net_Form_1st_Class.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Asp.Net_Form_1st_Class.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

       //   Yeh Get Karne Ke liye Hay
        public IActionResult adddata()
        {
            return View();
        }

        // Yeh Data Post Karne Ke liye Hay
        [HttpPost]
        public IActionResult adddata(string Email, string Password ) 
        {
            return View();
        }
      
      
    }
}