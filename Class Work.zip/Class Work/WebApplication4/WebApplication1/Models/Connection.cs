﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public class Connection : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Server=.;Database=school;User Id=sa;Password=aptech;TrustServerCertificate=True");

        }
        public DbSet<Student> Students { get; set; }
    }
    }

