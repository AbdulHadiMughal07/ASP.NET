﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net;
using System.Net.Mail;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
       Connection db = new Connection(); 

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult showdata()
        {
            var username = TempData["email"];
            ViewBag.Username = username;
            return View();
        }

        public IActionResult adddata()
        {
            return View();
        }

        [HttpPost]
        public IActionResult adddata(string Name , string Email , string Password , IFormFile Image)
        {
            var filename = Image.FileName;
            var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", filename);
            using (FileStream stream = new FileStream(path, FileMode.Create))
            {
                Image.CopyTo(stream);
            }
            Student std = new Student(Name , Email , Password , filename);
            db.Students.Add(std);
            db.SaveChanges();

            sendemail(Email, "This is testing email", $"<h1> Hello {Name}");
            TempData["SuccessMessage"] ="Succesfully Added";

            return View();            
        }

        public void sendemail(string to, string subject, string body)
        {
            MailMessage msg = new MailMessage("hadiaptech81@gmail.com", to, subject, body);
            msg.IsBodyHtml = true;
            SmtpClient clinet = new SmtpClient("smtp.gmail.com", 587)
            {
                Credentials = new NetworkCredential("hadiaptech81@gmail.com", "adouigbjrfeavcnv"),
                EnableSsl = true,
            };
            clinet.Send(msg);
            }
        public IActionResult getdata()
        {
            var data = db.Students.ToList();
            return View(data);
        }

        public IActionResult edit(int id)
        {
            var data = db.Students.Where(x => x.Id == id).FirstOrDefault();
            return View(data);
        }
        [HttpPost]
        public IActionResult edit(int id ,string Name, string Email, string Password)
        {
            var data = db.Students.Where(x => x.Id == id).FirstOrDefault();
            data.Name = Name;
            data.Email = Email;
            data.Password = Password;
            db.SaveChanges();
            return RedirectToAction("getdata");
        }
        public IActionResult delete(int id)
        {
            var data = db.Students.Where(x => x.Id == id).FirstOrDefault();
            db.Students.Remove(data);
            db.SaveChanges();
            return RedirectToAction("getdata");
        }
        public IActionResult login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult login(string email , string password)
        {
            var data = db.Students.Where(x => x.Email == email && x.Password == password).FirstOrDefault();
           
            if(data != null)
            {
                 HttpContext.Session.SetString("username",data.Name);
                return RedirectToAction("welcome");
            }
            return View();
        }

        public IActionResult welcome()
        {
            if(HttpContext.Session.GetString("username") != null)
            {
                return View();
            }
            else {
                return RedirectToAction("login");
            }
        }
        public IActionResult logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("login");
        }

    }
}