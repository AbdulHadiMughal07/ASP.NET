﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Student
    {
       public int Id { get; set; }
        [Required(ErrorMessage = "name is required")]
       public string Name { get; set; }

        [RegularExpression("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")]
        public string Email { get; set;}
        [MinLength(5)]
       public string Password { get; set;}

    }
}
