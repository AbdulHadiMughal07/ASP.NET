﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {

        Connection db = new Connection();
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult showdata()
        {
            return View();
        }

        public IActionResult adddata()
        {
            return View();
        }

        [HttpPost]
        public IActionResult adddata(string Name , string Email , string Password)
        {
            //ViewBag.Name = Name;
            //ViewBag.Email = Email;
            //ViewBag.Password = Password;

            Student std = new Student(Name,Email,Password);
            db.Students.Add(std);
            db.SaveChanges();

            return View();


            TempData["SuccessMessage"] = "Form has been successfully submitted, " + Name + "!";

            return View("privacy");
        }

       public IActionResult getdata()
        {
            var data = db.Students.ToList();

            return View(data);
        }
    }
}